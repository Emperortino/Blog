<?php
$UID = "";  // 你的B站UID
$Cookie = "";  // 你的B站Cookie
