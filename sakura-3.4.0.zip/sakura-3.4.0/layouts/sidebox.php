<?php 

	/**
	 * SIDEBOX - Table of contents
	 */

?>
<div class="toc-container"><div class="toc"></div></div>
